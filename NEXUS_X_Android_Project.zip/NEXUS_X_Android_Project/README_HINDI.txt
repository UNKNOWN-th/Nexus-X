NEXUS X Android WebView Project
================================

Is ZIP mein aapki uploaded nexus_x.html file Android app ke local assets mein rakhi gayi hai.

Important:
- Yeh Android Studio/Gradle project source hai, APK file nahi.
- Is environment mein Android SDK/Gradle build confirm nahi hua, isliye main APK banne ka jhootha daawa nahi kar raha.
- Website abhi prototype hai: login/password aur community data browser ke local storage mein rehte hain; real OTP/backend nahi hai. Real password use na karein.

APK banane ka sabse reliable tareeka:
1. Is ZIP ko kisi computer par download karke extract karein.
2. Android Studio install/open karein.
3. Open par extracted NEXUS_X_Android_Project folder select karein.
4. Gradle sync complete hone dein (Android SDK Platform 35 install karna pad sakta hai).
5. Build > Build Bundle(s) / APK(s) > Build APK(s) choose karein.
6. APK output app/build/outputs/apk/debug/app-debug.apk mein aayega.

Acer Android tablet par:
- ZIP ko extract karke seedha APK nahi banega, kyunki Gradle/Android SDK build tools chahiye.
- Agar sirf tablet hai, project ko kisi trusted cloud Android build service ya computer par build karna hoga.
